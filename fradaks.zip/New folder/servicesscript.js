document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission
    document.getElementById('popup').style.display = 'flex'; // Show the popup
});

function closePopup() {
    document.getElementById('popup').style.display = 'none'; // Hide the popup
}

// Function to handle the OK button click
function redirectToWebsite() {
    closePopup(); // Close the popup
    window.location.href = "homepage.html"; // Replace with your desired HTML file
}