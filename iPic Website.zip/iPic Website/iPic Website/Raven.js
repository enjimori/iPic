function redirectToWebsite() {
    closePopup(); // Close the popup
    window.location.href = "homepage.html"; // Replace with your desired HTML file
}