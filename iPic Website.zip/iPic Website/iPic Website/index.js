import cart from './cart.js';

const loadTemplate = async () => {
    try {
        // Use optional chaining and nullish coalescing for safer element selection
        const app = document.getElementById('app') ?? document.body;
        const temporaryContent = document.getElementById('temporaryContent');

        if (!app || !temporaryContent) {
            throw new Error('Required DOM elements are missing');
        }

        // Use async/await with fetch for cleaner promise handling
        const response = await fetch('/index.html');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const html = await response.text();
        
        // Update DOM
        app.innerHTML = html;
        
        const contentTab = document.getElementById('contentTab');
        
        if (contentTab) {
            contentTab.innerHTML = temporaryContent.innerHTML;
            temporaryContent.innerHTML = '';
        }

        // Initialize cart functionality
        cart();
    } catch (error) {
        console.error("Error loading template:", error);
        // Optional: Provide user-friendly error handling
        if (app) {
            app.innerHTML = `
                <div class="error-message">
                    Unable to load content. Please try again later.
                    <details>${error.message}</details>
                </div>
            `;
        }
    }
};

// Call the function when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', loadTemplate);

export default loadTemplate;
