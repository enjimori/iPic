const cart = () => {
    let iconCart = document.querySelector('.icon-cart');
    let closeBtn = document.querySelector('.cartTab .close');
    let body = document.querySelector('body');
    let cart = []; // Array to store cart items

    // Open the cart when the cart icon is clicked
    iconCart.addEventListener('click', () => {
        body.classList.toggle('activeTabCart');
    });

    // Close the cart when the close button is clicked
    closeBtn.addEventListener('click', () => {
        body.classList.remove('activeTabCart');
    });

    // Function to update product in the cart
    const setProductInCart = (idProduct, quantity, position) => {
        if (quantity > 0) {
            if (position < 0) {
                // If product is not in cart, add it
                cart.push({
                    product_id: idProduct,
                    quantity: quantity
                });
            } else {
                // If product is already in cart, update its quantity
                cart[position].quantity = quantity;
            }
        }
        // Refresh the cart HTML after updating it
        refreshCartHTML();
    };

    // Function to refresh the cart's UI
    const refreshCartHTML = () => {
        let listHTML = document.querySelector('.listCart');
        let totalHTML = document.querySelector('.icon-cart span');
        let totalQuantity = 0;
        let totalPrice = 0;  // Calculate total price

        // Clear only the product list content, not the entire cartTab
        listHTML.innerHTML = ''; // Clear current list

        if (cart.length === 0) {
            // If cart is empty, display the "empty cart" message
            listHTML.innerHTML = 'Your cart is empty.';
        } else {
            // Rebuild the cart items
            cart.forEach(item => {
                totalQuantity += item.quantity;

                // Get product details by its ID
                let product = getProductById(item.product_id);
                let productPrice = product ? product.price : 0;
                let productName = product ? product.name : 'Product Name';
                totalPrice += item.quantity * productPrice;

                // Create the cart item HTML
                let cartItemElement = document.createElement('div');
                cartItemElement.classList.add('cart-item');
                cartItemElement.innerHTML = `
                    <div class="name">${productName}</div>
                    <div class="totalPrice">Php ${productPrice.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                    <div class="quantity">
                        <span class="minus" data-id="${item.product_id}">-</span>
                        <span class="quantity-value">${item.quantity}</span>
                        <span class="plus" data-id="${item.product_id}">+</span>
                    </div>
                    <div class="total-item-price">Total: Php ${(item.quantity * productPrice).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                    <button class="remove" data-id="${item.product_id}">Remove</button>
                `;
                listHTML.appendChild(cartItemElement);
            });

            // Show the total price of all items at the bottom
            let totalElement = document.createElement('div');
            totalElement.innerHTML = `<strong>Total: Php ${totalPrice.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>`;
            listHTML.appendChild(totalElement);
        }

        // Update the cart icon with the total quantity
        totalHTML.innerText = totalQuantity;

        // Add event listener to remove items from the cart
        document.querySelectorAll('.cart-item .remove').forEach(button => {
            button.addEventListener('click', (event) => {
                let productId = event.target.dataset.id;
                removeFromCart(productId);
            });
        });

        // Add event listeners for increase/decrease buttons
        document.querySelectorAll('.quantity .plus').forEach(button => {
            button.addEventListener('click', (event) => {
                let productId = event.target.dataset.id;
                let position = cart.findIndex(item => item.product_id == productId);
                let quantity = cart[position].quantity + 1;
                setProductInCart(productId, quantity, position);
            });
        });

        document.querySelectorAll('.quantity .minus').forEach(button => {
            button.addEventListener('click', (event) => {
                let productId = event.target.dataset.id;
                let position = cart.findIndex(item => item.product_id == productId);
                let quantity = cart[position].quantity - 1;
                if (quantity > 0) {
                    setProductInCart(productId, quantity, position);
                } else {
                    removeFromCart(productId);
                }
            });
        });
    };

    // Function to remove a product from the cart
    const removeFromCart = (idProduct) => {
        cart = cart.filter(item => item.product_id != idProduct);
        refreshCartHTML();
    };

    // Function to get product details by ID
    const getProductById = (productId) => {
        // Example product data
        const products = [
            { id: 1, name: 'Canon EOS R8', price: 104998.00 },
            { id: 2, name: 'Canon EOS 90D', price: 46130.00 },
            { id: 3, name: 'Canon EOS 1200D', price: 310759.00 },
            { id: 4, name: 'Canon EOS 80D', price: 40903.00 },
            { id: 5, name: 'Sony Alpha A7', price: 62785.00 },
            { id: 6, name: 'Zhiyun Weebill-S', price: 14378.00 },
            { id: 7, name: 'Zhiyun Smooth Q3', price: 3376.00 },
            { id: 8, name: 'Viltrox AF 20mm f/2.8 Lens (Sony E)', price: 11153.00 },
            { id: 9, name: 'RangePod Smart', price: 7867.00 },
            { id: 10, name: 'Compact Advanced Kit Tripod', price: 5738.00 },
            { id: 11, name: 'Extendable Tripod', price: 2675.00 },
            { id: 12, name: 'Spark Propeller Guard', price: 360.00 },
            { id: 13, name: 'Compact Action Kit Tripod', price: 3474.00 },
            { id: 14, name: 'Karma Grip Handle', price: 5686.00 },
            { id: 15, name: 'Godox AD600Pro II All-in-One Outdoor Flash', price: 4578.00 },
            { id: 16, name: 'Godox AD200Pro II TTL Pocket Flash', price: 3967.00 },
            { id: 17, name: 'Sigma 14mm f/1.4 DG DN Art Lens (Sony E)', price: 93990.00 },
            { id: 18, name: 'Samyang 50mm F1.4 AS UMC', price: 16500.00 },
            { id: 19, name: 'Samyang 300mm F6.3 ED UMC CS', price: 16000.00 },
            { id: 20, name: 'Black Magic Design CINEURSAMUPROTEF Blackmagic URSA Mini Pro EF Mount', price: 13535.00 },
            { id: 21, name: 'Saramonic Vmic4 Dual-Capsule Camera-Mount Supercardioid Shotgun Microphone', price: 3542.00 },
            { id: 22, name: 'Nicefoto 50cm Quick Release Mini Bowens Mount Softbox', price: 1800.00 },
            { id: 23, name: 'Saramonic BTW Wireless Bluetooth Clip-On Microphone', price: 2747.00 },
            { id: 24, name: 'Apex XPrompter 19 Inches Portable Presidential Teleprompter with Rolling Case', price: 64854.00 },
            { id: 25, name: 'Panasonic HC-X1500 UHD 4K HDMI Pro Camcorder with 24x Zoom', price: 6543.00 },
            { id: 26, name: 'DJI Osmo Action 5 Pro Adventure Combo', price: 27985.00 },
            { id: 27, name: 'Blackmagic Design URSA Mini Pro 4.6K G2 Digital Cinema Camera', price: 462432.00 },
            { id: 28, name: 'Hollyland VenusLiv V2 4K Live Streaming Video Camera', price: 55568.00 },
            { id: 29, name: 'Benro TSL08AS2CSH Slim Tripod Kit with S2CSH Head (Aluminum)', price: 4856.00 },
            { id: 30, name: 'YUNTENG VCT-880 Portable Aluminum Alloy 3-Section Tripod 5kg Capacity', price: 310759.00 }
        ];

        return products.find(product => product.id == productId);
    };

    // Event listeners for "Add to Cart" buttons
    document.addEventListener('click', (event) => {
        let buttonClick = event.target;
        let idProduct = buttonClick.dataset.id;

        // Check if buttonClick has the `addCart` class before continuing
        if (buttonClick.classList.contains('addCart')) {
            let position = cart.findIndex(item => item.product_id == idProduct);
            let quantity = position < 0 ? 1 : cart[position].quantity + 1;
            setProductInCart(idProduct, quantity, position);
        }
    });

    return {
        cartItems,
        refreshCartHTML
    };
};

export default cart;
